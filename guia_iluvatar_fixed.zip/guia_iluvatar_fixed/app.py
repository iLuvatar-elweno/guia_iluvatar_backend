#!/usr/bin/env python3
"""
Guía iLuvatar - Robust FastAPI backend for EMET Surf
This version uses lxml with recovery to tolerate malformed XML from sources.
Features:
 - lxml XML parsing with recover=True (won't crash on bad XML)
 - background refresh with disk cache fallback
 - endpoints: /catalog/channels, /meta/{id}, /epg.xml.gz, /logo.png, /health
 - rotating file logs
 - safe handling when sources fail
"""
import os, gzip, io, time, asyncio, logging
from logging.handlers import RotatingFileHandler
from typing import Dict, Any
from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import FileResponse, JSONResponse
import httpx

# use lxml for robust parsing (recover).
from lxml import etree

CFG = {
    "TDT_URL": os.environ.get("TDT_URL", "https://www.tdtchannels.com/epg/TV.xml.gz"),
    "MOV_URL": os.environ.get("MOV_URL", "https://raw.githubusercontent.com/MPAndrew/EpgGratis/master/guide.xml.gz"),
    "REFRESH_INTERVAL": int(os.environ.get("REFRESH_INTERVAL", str(60*60*3))),  # seconds
    "CACHE_PATH": os.environ.get("CACHE_PATH", "cache/epg.xml.gz"),
    "MAX_PROGRAMS": int(os.environ.get("MAX_PROGRAMS", "24")),
    "HTTPX_TIMEOUT": int(os.environ.get("HTTPX_TIMEOUT", "20")),
    "MANIFEST_LOGO": os.environ.get("MANIFEST_LOGO", "https://kodifacil.com/emet/logo.png"),
}

# Logging
logger = logging.getLogger("guia_iluvatar")
logger.setLevel(logging.INFO)
fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
ch = logging.StreamHandler()
ch.setFormatter(fmt)
logger.addHandler(ch)
fh = RotatingFileHandler("guia_iluvatar.log", maxBytes=4*1024*1024, backupCount=3)
fh.setFormatter(fmt)
logger.addHandler(fh)

app = FastAPI(title="Guía iLuvatar")

_CACHE: Dict[str, Any] = {
    "raw": None,
    "channels": {},
    "programmes": {},
    "fetched_at": 0,
    "sources": []
}

async def fetch_bytes(url: str) -> bytes:
    timeout = CFG["HTTPX_TIMEOUT"]
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(url)
            r.raise_for_status()
            return r.content
    except Exception as e:
        logger.warning("Fetch failed %s: %s", url, e)
        raise

def try_decompress(data: bytes) -> bytes:
    if not data:
        return b""
    # gzip magic
    if data[:2] == b'\x1f\x8b':
        try:
            import gzip as _gzip, io as _io
            with _gzip.GzipFile(fileobj=_io.BytesIO(data)) as gf:
                return gf.read()
        except Exception:
            return data
    return data

def parse_with_lxml_safe(xml_bytes: bytes):
    channels = {}
    programmes = {}
    if not xml_bytes:
        return channels, programmes
    try:
        parser = etree.XMLParser(recover=True, encoding='utf-8')
        root = etree.fromstring(xml_bytes, parser=parser)
    except Exception as e:
        logger.warning("lxml parse root failed: %s", e)
        return channels, programmes
    for ch in root.findall('.//channel'):
        cid = ch.get('id')
        name_el = ch.find('.//display-name')
        name = name_el.text.strip() if name_el is not None and name_el.text else cid
        icon = ch.find('.//icon')
        logo = icon.get('src') if icon is not None and icon.get('src') else None
        channels[cid] = {"id": cid, "name": name, "logo": logo}
    for p in root.findall('.//programme'):
        try:
            ch_id = p.get('channel')
            title = (p.findtext('title') or "").strip()
            desc = (p.findtext('desc') or "").strip()
            start = p.get('start')
            stop = p.get('stop')
            programmes.setdefault(ch_id, []).append({
                "title": title,
                "desc": desc,
                "start": start,
                "stop": stop
            })
        except Exception as e:
            logger.debug("Skipping malformed programme: %s", e)
            continue
    return channels, programmes

async def refresh(force: bool = False):
    now = time.time()
    if not force and _CACHE["raw"] and _CACHE["fetched_at"] + CFG["REFRESH_INTERVAL"] > now:
        logger.info("Cache fresh, skipping refresh")
        return
    logger.info("Refreshing EPG...")
    sources = []
    tdt_b = b""
    mov_b = b""
    try:
        raw = await fetch_bytes(CFG["TDT_URL"])
        tdt_b = try_decompress(raw)
        sources.append({"url": CFG["TDT_URL"], "ok": True, "size": len(tdt_b)})
    except Exception:
        tdt_b = b""
        sources.append({"url": CFG["TDT_URL"], "ok": False, "size": 0})
    try:
        raw = await fetch_bytes(CFG["MOV_URL"])
        mov_b = try_decompress(raw)
        sources.append({"url": CFG["MOV_URL"], "ok": True, "size": len(mov_b)})
    except Exception:
        mov_b = b""
        sources.append({"url": CFG["MOV_URL"], "ok": False, "size": 0})
    combined = None
    if tdt_b or mov_b:
        try:
            parser = etree.XMLParser(recover=True)
            root_main = etree.Element('tv')
            for feed in (tdt_b, mov_b):
                if not feed:
                    continue
                try:
                    rt = etree.fromstring(feed, parser=parser)
                    for child in rt:
                        root_main.append(child)
                except Exception as e:
                    logger.warning("feed parse skip: %s", e)
            combined = etree.tostring(root_main, encoding='utf-8', xml_declaration=True)
        except Exception as e:
            logger.exception("Merge failed: %s", e)
            combined = tdt_b or mov_b or b""
    else:
        combined = tdt_b or mov_b or b""
    if not combined:
        logger.error("No EPG data available after fetch attempts.")
        return
    try:
        os.makedirs(os.path.dirname(CFG["CACHE_PATH"]), exist_ok=True)
        with open(CFG["CACHE_PATH"], "wb") as f:
            f.write(gzip.compress(combined))
    except Exception as e:
        logger.warning("Failed to write disk cache: %s", e)
    try:
        channels, programmes = parse_with_lxml_safe(combined)
        _CACHE.update({"raw": combined, "channels": channels, "programmes": programmes, "fetched_at": int(now), "sources": sources})
        logger.info("EPG refreshed: channels=%d total_programmes=%d", len(channels), sum(len(v) for v in programmes.values()))
    except Exception as e:
        logger.exception("Parsing merged EPG failed: %s", e)

if os.path.exists(CFG["CACHE_PATH"]):
    try:
        with open(CFG["CACHE_PATH"], "rb") as f:
            data = gzip.decompress(f.read())
            ch, pg = parse_with_lxml_safe(data)
            _CACHE.update({"raw": data, "channels": ch, "programmes": pg, "fetched_at": int(time.time())})
            logger.info("Loaded EPG from disk cache (%d channels)", len(ch))
    except Exception as e:
        logger.warning("Failed to load disk cache: %s", e)

@app.on_event("startup")
async def startup_event():
    await refresh(force=True)
    async def loop():
        while True:
            try:
                await asyncio.sleep(CFG["REFRESH_INTERVAL"])
                await refresh(force=True)
            except Exception as e:
                logger.exception("Background refresh error: %s", e)
    asyncio.create_task(loop())

@app.get("/catalog/channels")
async def catalog():
    if not _CACHE["channels"]:
        raise HTTPException(status_code=503, detail="EPG not ready")
    metas = []
    for cid, ch in _CACHE["channels"].items():
        metas.append({"id": cid, "type": "tv", "title": ch.get("name"), "poster": ch.get("logo") or "/logo.png", "description": ""})
    return JSONResponse({"metas": metas})

@app.get("/meta/{cid}")
async def meta(cid: str):
    ch = _CACHE["channels"].get(cid)
    if not ch:
        raise HTTPException(status_code=404, detail="channel not found")
    progs = _CACHE["programmes"].get(cid, [])[:CFG["MAX_PROGRAMS"]]
    return JSONResponse({"id": cid, "type": "tv", "title": ch.get("name"), "poster": ch.get("logo") or "/logo.png", "programming": progs})

@app.get("/epg.xml.gz")
async def epg():
    if _CACHE["raw"]:
        return Response(content=gzip.compress(_CACHE["raw"]), media_type="application/gzip", headers={"Content-Encoding":"gzip"})
    if os.path.exists(CFG["CACHE_PATH"]):
        return FileResponse(CFG["CACHE_PATH"], media_type="application/gzip")
    raise HTTPException(status_code=503, detail="epg not available")

@app.get("/logo.png")
async def logo():
    if os.path.exists("logo.png"):
        return FileResponse("logo.png", media_type="image/png")
    raise HTTPException(status_code=404, detail="logo not found")

@app.get("/health")
async def health():
    return JSONResponse({"status": "ok", "cached_at": _CACHE.get("fetched_at"), "channels": len(_CACHE.get("channels", {})), "sources": _CACHE.get("sources")})
